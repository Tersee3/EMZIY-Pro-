/* Utilities */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const byId = (id) => document.getElementById(id);

const state = {
  view: "home",
  chat: {
    room: "lounge",
    nickname: `Guest${Math.floor(Math.random() * 1000)}`,
    echo: false
  },
  reelsLayout: "grid",
  music: {
    library: []
  }
};

/* SPA Navigation */
function activateView(id) {
  state.view = id;
  $$(".view").forEach((v) => v.classList.toggle("active", v.id === id));
  $$(".nav-link").forEach((b) => {
    const active = b.dataset.target === id;
    b.classList.toggle("active", active);
    b.setAttribute("aria-current", active ? "page" : "false");
  });
}
$$(".nav-link").forEach((btn) => {
  btn.addEventListener("click", () => activateView(btn.dataset.target));
});
$$(".btn[data-target]").forEach((btn) => {
  btn.addEventListener("click", (e) => {
    e.preventDefault();
    activateView(btn.dataset.target);
  });
});

/* Header year */
byId("year").textContent = new Date().getFullYear();

/* -------------------- Chat -------------------- */
const chatLog = byId("chat-log");
const chatInput = byId("chat-input");
const chatForm = byId("chat-form");
const chatRoom = byId("chat-room");
const chatNick = byId("chat-nickname");
const chatJoin = byId("chat-join");
const chatClear = byId("chat-clear");
const chatEcho = byId("chat-echo");

function storageKey(room) {
  return `emziy.chat.${room}`;
}

function loadChat(room) {
  chatLog.innerHTML = "";
  const data = JSON.parse(localStorage.getItem(storageKey(room)) || "[]");
  data.forEach(renderMessage);
  chatLog.scrollTop = chatLog.scrollHeight;
}

function saveMessage(room, msg) {
  const data = JSON.parse(localStorage.getItem(storageKey(room)) || "[]");
  data.push(msg);
  localStorage.setItem(storageKey(room), JSON.stringify(data).slice(0, 500000)); // guard size
}

function renderMessage({ user, text, ts }) {
  const el = document.createElement("div");
  el.className = `message ${user === state.chat.nickname ? "me" : ""}`;
  el.innerHTML = `
    <div class="avatar">${(user || "?").slice(0, 1).toUpperCase()}</div>
    <div class="bubble">
      <div class="meta">${user} • ${new Date(ts).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  })}</div>
      <div class="text">${escapeHTML(text)}</div>
    </div>`;
  chatLog.appendChild(el);
}

function escapeHTML(s) {
  return s.replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[
        c
      ])
  );
}

function joinRoom() {
  const room = (chatRoom.value.trim() || "lounge").toLowerCase();
  const nick = chatNick.value.trim() || state.chat.nickname;
  state.chat.room = room;
  state.chat.nickname = nick;
  localStorage.setItem("emziy.chat.lastRoom", room);
  localStorage.setItem("emziy.chat.nickname", nick);
  loadChat(room);
}

function clearRoom() {
  const room = state.chat.room;
  localStorage.removeItem(storageKey(room));
  loadChat(room);
}

chatJoin.addEventListener("click", joinRoom);
chatClear.addEventListener("click", clearRoom);
chatEcho.addEventListener(
  "change",
  (e) => (state.chat.echo = e.target.checked)
);

chatForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;
  const msg = { user: state.chat.nickname, text, ts: Date.now() };
  renderMessage(msg);
  saveMessage(state.chat.room, msg);
  chatInput.value = "";
  chatLog.scrollTop = chatLog.scrollHeight;

  // Optional assistant echo
  if (state.chat.echo) {
    setTimeout(() => {
      const reply = {
        user: "Assistant",
        text: smartReply(text),
        ts: Date.now()
      };
      renderMessage(reply);
      saveMessage(state.chat.room, reply);
      chatLog.scrollTop = chatLog.scrollHeight;
    }, 500 + Math.random() * 700);
  }
});

function smartReply(text) {
  const t = text.toLowerCase();
  if (t.startsWith("/help"))
    return "Commands: /help, /clear (clears room history).";
  if (t.startsWith("/clear")) {
    clearRoom();
    return "Room cleared.";
  }
  if (t.includes("hello") || t.includes("hi"))
    return "Hello! What are you up to?";
  if (t.includes("movie"))
    return "Try the Movies Center tab to search and embed videos.";
  if (t.includes("music"))
    return "Head to Music to stream tracks or add your own.";
  return `You said: "${text}"`;
}

// Load defaults
chatRoom.value = localStorage.getItem("emziy.chat.lastRoom") || state.chat.room;
chatNick.value =
  localStorage.getItem("emziy.chat.nickname") || state.chat.nickname;
joinRoom();

/* -------------------- Reels -------------------- */
const reelFile = byId("reel-file");
const reelDesc = byId("reel-desc");
const reelAdd = byId("reel-add");
const reelsContainer = byId("reels-container");
const reelsGridBtn = byId("reels-grid");
const reelsListBtn = byId("reels-list");

reelAdd.addEventListener("click", () => {
  const file = reelFile.files?.[0];
  if (!file) return alert("Choose a video to upload.");
  const url = URL.createObjectURL(file);
  const desc = reelDesc.value.trim() || file.name;

  const card = document.createElement("article");
  card.className = "reel-card";
  card.innerHTML = `
    <video controls preload="metadata" src="${url}"></video>
    <div class="meta">
      <h4>${escapeHTML(file.name)}</h4>
      <p>${escapeHTML(desc)}</p>
    </div>
  `;
  reelsContainer.prepend(card);
  reelFile.value = "";
  reelDesc.value = "";
});

reelsGridBtn.addEventListener("click", () => {
  state.reelsLayout = "grid";
  reelsContainer.classList.add("grid");
  reelsContainer.classList.remove("list");
  reelsGridBtn.setAttribute("aria-pressed", "true");
  reelsListBtn.setAttribute("aria-pressed", "false");
});
reelsListBtn.addEventListener("click", () => {
  state.reelsLayout = "list";
  reelsContainer.classList.add("list");
  reelsContainer.classList.remove("grid");
  reelsListBtn.setAttribute("aria-pressed", "true");
  reelsGridBtn.setAttribute("aria-pressed", "false");
});

/* -------------------- Movies Center -------------------- */
const movieQuery = byId("movie-query");
const moviePlatform = byId("movie-platform");
const movieSearch = byId("movie-search");
const movieResults = byId("movie-results");
const movieUrl = byId("movie-url");
const movieEmbedBtn = byId("movie-embed");
const moviePlayer = byId("movie-player");
const movieDownload = byId("movie-download");

movieSearch.addEventListener("click", () => {
  const q = encodeURIComponent((movieQuery.value || "").trim());
  if (!q) return alert("Enter a search term.");
  const platform = moviePlatform.value;
  const urls = {
    youtube: `https://www.youtube.com/results?search_query=${q}`,
    facebook: `https://www.facebook.com/search/videos/?q=${q}`,
    vimeo: `https://vimeo.com/search?q=${q}`,
    dailymotion: `https://www.dailymotion.com/search/${q}`
  };
  const openers = {
    youtube: "YouTube",
    facebook: "Facebook",
    vimeo: "Vimeo",
    dailymotion: "Dailymotion"
  };
  movieResults.innerHTML = "";
  Object.entries(urls).forEach(([key, url]) => {
    if (platform !== key) return;
    const a = document.createElement("a");
    a.href = url;
    a.target = "_blank";
    a.rel = "noopener";
    a.textContent = `Open on ${openers[key]}`;
    movieResults.appendChild(a);
  });
});

movieEmbedBtn.addEventListener("click", () => {
  const url = (movieUrl.value || "").trim();
  if (!url) return alert("Paste a video URL.");
  const embedInfo = buildEmbed(url);
  moviePlayer.innerHTML = "";

  if (embedInfo.type === "iframe") {
    const iframe = document.createElement("iframe");
    iframe.allow =
      "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share";
    iframe.allowFullscreen = true;
    iframe.src = embedInfo.src;
    moviePlayer.appendChild(iframe);
  } else if (embedInfo.type === "video") {
    const video = document.createElement("video");
    video.controls = true;
    video.src = embedInfo.src;
    moviePlayer.appendChild(video);
  } else {
    moviePlayer.textContent =
      "This link cannot be embedded here. Try opening it on the platform.";
  }

  // Download toggle: only direct media links
  const downloadable = /\.(mp4|webm|ogg)(\?.*)?$/i.test(url);
  movieDownload.toggleAttribute("disabled", !downloadable);
  movieDownload.href = downloadable ? url : "#";
});

function buildEmbed(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, "");

    // YouTube watch -> embed
    if (host.includes("youtube.com")) {
      const v = u.searchParams.get("v");
      if (v)
        return { type: "iframe", src: `https://www.youtube.com/embed/${v}` };
      // youtu.be links handled below
    }
    if (host === "youtu.be") {
      const id = u.pathname.slice(1);
      if (id)
        return { type: "iframe", src: `https://www.youtube.com/embed/${id}` };
    }

    // Vimeo
    if (host.includes("vimeo.com")) {
      const id = u.pathname.split("/").filter(Boolean).pop();
      if (id && /^\d+$/.test(id))
        return { type: "iframe", src: `https://player.vimeo.com/video/${id}` };
    }

    // Dailymotion
    if (host.includes("dailymotion.com")) {
      const parts = u.pathname.split("/");
      const id =
        parts.find((p) => /^video/.test(p))?.replace("video/", "") ||
        parts.pop();
      if (id)
        return {
          type: "iframe",
          src: `https://www.dailymotion.com/embed/video/${id}`
        };
    }

    // Direct media
    if (/\.(mp4|webm|ogg)(\?.*)?$/i.test(url)) {
      return { type: "video", src: url };
    }

    // Fallback
    return { type: "none" };
  } catch {
    return { type: "none" };
  }
}

/* -------------------- Music -------------------- */
const musicSearch = byId("music-search");
const musicFile = byId("music-file");
const musicAdd = byId("music-add");
const musicList = byId("music-list");
const musicCount = byId("music-count");
const audio = byId("audio");
const nowPlaying = byId("now-playing");

// Curated, royalty-free/demo samples
const sampleTracks = [
  {
    title: "Neon Drift",
    artist: "Aether City",
    genre: "Synthwave",
    url: "https://filesamples.com/samples/audio/mp3/sample3.mp3"
  },
  {
    title: "Ocean Breeze",
    artist: "Open Air",
    genre: "Chillout",
    url: "https://filesamples.com/samples/audio/mp3/sample2.mp3"
  },
  {
    title: "Pulse Runner",
    artist: "Night Circuit",
    genre: "Electronic",
    url: "https://filesamples.com/samples/audio/mp3/sample1.mp3"
  },
  {
    title: "Glass Horizon",
    artist: "Blue Hour",
    genre: "Ambient",
    url: "https://filesamples.com/samples/audio/mp3/sample4.mp3"
  }
];

state.music.library = [...sampleTracks];
renderLibrary();

musicSearch.addEventListener("input", renderLibrary);

musicAdd.addEventListener("click", () => {
  const file = musicFile.files?.[0];
  if (!file) return alert("Choose an audio file to add.");
  const url = URL.createObjectURL(file);
  const track = {
    title: file.name.replace(/\.[^.]+$/, ""),
    artist: "My Upload",
    genre: "Local",
    url
  };
  state.music.library.unshift(track);
  musicFile.value = "";
  renderLibrary();
});

function renderLibrary() {
  const q = (musicSearch.value || "").toLowerCase().trim();
  const list = state.music.library.filter((t) =>
    [t.title, t.artist, t.genre].join(" ").toLowerCase().includes(q)
  );

  musicList.innerHTML = "";
  list.forEach((t) => {
    const li = document.createElement("li");
    li.className = "track";
    li.innerHTML = `
      <div class="info">
        <span class="title">${escapeHTML(t.title)}</span>
        <span class="sub">${escapeHTML(t.artist)} • ${escapeHTML(
      t.genre
    )}</span>
      </div>
      <button class="btn small play">Play</button>
      <a class="btn small" href="${t.url}" download>Download</a>
    `;
    li.querySelector(".play").addEventListener("click", () => playTrack(t));
    musicList.appendChild(li);
  });
  musicCount.textContent = String(list.length);
}

function playTrack(track) {
  audio.src = track.url;
  audio.play();
  nowPlaying.textContent = `Now playing: ${track.title} — ${track.artist}`;
}

/* Accessibility: allow Enter to trigger embedded actions */
["movie-query", "movie-url", "music-search", "chat-input"].forEach((id) => {
  const el = byId(id);
  el?.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && id === "movie-query") movieSearch.click();
    if (e.key === "Enter" && id === "movie-url") movieEmbedBtn.click();
  });
});
